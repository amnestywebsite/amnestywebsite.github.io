#!/bin/bash
 
cp node_modules/iframe-resizer/js/iframeResizer.contentWindow.js javascripts/vendor/iframeResizer.contentWindow.js;
cp node_modules/iframe-resizer/js/iframeResizer.js javascripts/vendor-external/iframeResizer.js;